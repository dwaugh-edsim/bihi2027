# yt-grab

Simple local/LAN video & MP3 downloader web page.

## How to run

Double-click `start.bat` (or run `python server.py`).

- **On the same laptop:** opens `http://localhost:8787` automatically.
- **From another laptop on your Wi-Fi:** open the `LAN: http://<ip>:8787` URL printed in the console.

On the first download, `server.py` automatically downloads `yt-dlp.exe` and `ffmpeg.exe` into `./tools/`.

## Optional PIN protection

Set `YTGRAB_PIN` before starting if you ever want to require a PIN:

```powershell
$env:YTGRAB_PIN = "1234"
python server.py
```

#!/usr/bin/env python3
"""
yt-grab: Minimal local/LAN YouTube downloader web server.
Zero third-party Python dependencies. Auto-bootstraps yt-dlp and ffmpeg on Windows.
"""

from __future__ import annotations

import hmac
import http.server
import io
import json
import mimetypes
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
TOOLS_DIR = BASE_DIR / "tools"
PORT = int(os.environ.get("YTGRAB_PORT", "8787"))
PIN_CODE = os.environ.get("YTGRAB_PIN", "").strip()

YTDLP_URL = "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe"
FFMPEG_ZIP_URL = "https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"

FORMAT_ARGS: dict[str, list[str]] = {
    "1080": [
        "-f",
        "bv*[height<=1080][ext=mp4]+ba[ext=m4a]/b[height<=1080][ext=mp4]/bv*[height<=1080]+ba/b[height<=1080]/best",
        "--merge-output-format",
        "mp4",
    ],
    "720": [
        "-f",
        "bv*[height<=720][ext=mp4]+ba[ext=m4a]/b[height<=720][ext=mp4]/bv*[height<=720]+ba/b[height<=720]/best",
        "--merge-output-format",
        "mp4",
    ],
    "480": [
        "-f",
        "bv*[height<=480][ext=mp4]+ba[ext=m4a]/b[height<=480][ext=mp4]/bv*[height<=480]+ba/b[height<=480]/best",
        "--merge-output-format",
        "mp4",
    ],
    "mp3": [
        "-x",
        "--audio-format",
        "mp3",
        "--audio-quality",
        "192K",
    ],
}

JOBS: dict[str, dict] = {}
JOBS_LOCK = threading.Lock()
TOOLS_LOCK = threading.Lock()

PROGRESS_RE = re.compile(r"\[download\]\s+(\d+(?:\.\d+)?)%")


def find_tool(name: str) -> Path | None:
    """Return path to executable in ./tools or on PATH."""
    exe = f"{name}.exe" if os.name == "nt" and not name.endswith(".exe") else name
    local = TOOLS_DIR / exe
    if local.is_file():
        return local
    found = shutil.which(name)
    return Path(found) if found else None


def download_to_file(url: str, dest: Path) -> None:
    req = urllib.request.Request(url, headers={"User-Agent": "yt-grab/1.0"})
    with urllib.request.urlopen(req, timeout=120) as resp, open(dest, "wb") as f:
        shutil.copyfileobj(resp, f)


def ensure_tools(status_cb) -> tuple[Path, Path | None]:
    """Ensure yt-dlp (and ffmpeg on Windows) are available."""
    with TOOLS_LOCK:
        TOOLS_DIR.mkdir(parents=True, exist_ok=True)
        ytdlp = find_tool("yt-dlp")
        if ytdlp is None:
            if os.name != "nt":
                raise RuntimeError("yt-dlp not found on PATH. Install yt-dlp first.")
            status_cb("Downloading yt-dlp (first-time setup)...", 5)
            target = TOOLS_DIR / "yt-dlp.exe"
            tmp = TOOLS_DIR / "yt-dlp.exe.part"
            download_to_file(YTDLP_URL, tmp)
            tmp.replace(target)
            ytdlp = target

        ffmpeg = find_tool("ffmpeg")
        if ffmpeg is None and os.name == "nt":
            status_cb("Downloading ffmpeg (first-time setup, ~40 MB)...", 10)
            zip_tmp = TOOLS_DIR / "ffmpeg.zip.part"
            try:
                download_to_file(FFMPEG_ZIP_URL, zip_tmp)
                with zipfile.ZipFile(zip_tmp) as zf:
                    for member in zf.namelist():
                        base = os.path.basename(member)
                        if base in ("ffmpeg.exe", "ffprobe.exe"):
                            with zf.open(member) as src, open(TOOLS_DIR / base, "wb") as dst:
                                shutil.copyfileobj(src, dst)
                ffmpeg = find_tool("ffmpeg")
            finally:
                if zip_tmp.exists():
                    zip_tmp.unlink(missing_ok=True)

        return ytdlp, ffmpeg


def update_job(job_id: str, **kwargs) -> None:
    with JOBS_LOCK:
        if job_id in JOBS:
            JOBS[job_id].update(kwargs)


def run_download_job(job_id: str, url: str, fmt: str) -> None:
    temp_dir = Path(tempfile.mkdtemp(prefix="ytgrab_"))
    update_job(job_id, temp_dir=str(temp_dir))

    def set_status(message: str, progress: float | None = None) -> None:
        fields: dict = {"status_text": message}
        if progress is not None:
            fields["progress"] = progress
        update_job(job_id, **fields)

    try:
        ytdlp, ffmpeg = ensure_tools(set_status)
        set_status("Starting download...", 15)

        out_template = str(temp_dir / "%(title).120B.%(ext)s")
        cmd = [
            str(ytdlp),
            "--no-playlist",
            "--newline",
            "--no-warnings",
            "--restrict-filenames",
            *FORMAT_ARGS[fmt],
        ]
        if ffmpeg is not None:
            cmd.extend(["--ffmpeg-location", str(ffmpeg.parent)])
        cmd.extend(["-o", out_template, "--", url])

        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=creationflags,
        )

        last_lines: list[str] = []
        assert proc.stdout is not None
        for raw_line in proc.stdout:
            line = raw_line.strip()
            if not line:
                continue
            last_lines.append(line)
            if len(last_lines) > 20:
                last_lines.pop(0)

            match = PROGRESS_RE.search(line)
            if match:
                pct = float(match.group(1))
                scaled = 15.0 + (pct * 0.75)
                set_status(f"Downloading... {pct:.0f}%", scaled)
            elif "[Merger]" in line or "[ExtractAudio]" in line or "Post-process" in line:
                set_status("Finishing conversion...", 93)

        rc = proc.wait()
        if rc != 0:
            err_detail = last_lines[-1] if last_lines else f"yt-dlp exited with code {rc}"
            raise RuntimeError(err_detail)

        files = [p for p in temp_dir.iterdir() if p.is_file() and not p.name.endswith(".part")]
        if not files:
            raise RuntimeError("Download finished, but no output file was found.")

        out_file = max(files, key=lambda p: p.stat().st_size)
        update_job(
            job_id,
            state="ready",
            progress=100,
            status_text="Ready! Sending file...",
            file_path=str(out_file),
            file_name=out_file.name,
            file_size=out_file.stat().st_size,
        )
    except Exception as exc:
        update_job(
            job_id,
            state="error",
            status_text=str(exc),
            error=str(exc),
        )
        shutil.rmtree(temp_dir, ignore_errors=True)


def cleanup_old_jobs() -> None:
    """Periodically remove temp files for abandoned jobs older than 30 minutes."""
    while True:
        time.sleep(300)
        cutoff = time.time() - 1800
        to_delete: list[str] = []
        with JOBS_LOCK:
            for jid, job in list(JOBS.items()):
                if job.get("created_at", 0) < cutoff and job.get("state") in ("ready", "error", "downloaded"):
                    temp_dir = job.get("temp_dir")
                    if temp_dir:
                        shutil.rmtree(temp_dir, ignore_errors=True)
                    to_delete.append(jid)
            for jid in to_delete:
                JOBS.pop(jid, None)


def fetch_video_info(url: str) -> dict:
    """Fetch basic title/author/thumbnail via oEmbed (fast) or yt-dlp --dump-json."""
    parsed = urllib.parse.urlparse(url)
    host = (parsed.hostname or "").lower()
    if "youtube.com" in host or "youtu.be" in host:
        oembed = "https://www.youtube.com/oembed?url=" + urllib.parse.quote(url, safe="") + "&format=json"
        try:
            req = urllib.request.Request(oembed, headers={"User-Agent": "yt-grab/1.0"})
            with urllib.request.urlopen(req, timeout=4) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return {
                    "ok": True,
                    "title": data.get("title", ""),
                    "author": data.get("author_name", ""),
                    "thumbnail": data.get("thumbnail_url", ""),
                }
        except Exception:
            pass

    ytdlp = find_tool("yt-dlp")
    if ytdlp is not None:
        try:
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            out = subprocess.check_output(
                [str(ytdlp), "--no-playlist", "--no-warnings", "--dump-single-json", "--", url],
                stderr=subprocess.DEVNULL,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=10,
                creationflags=creationflags,
            )
            data = json.loads(out)
            return {
                "ok": True,
                "title": data.get("title", ""),
                "author": data.get("uploader", "") or data.get("channel", ""),
                "thumbnail": data.get("thumbnail", ""),
            }
        except Exception:
            pass

    return {"ok": False}


def is_valid_http_url(url: str) -> bool:
    try:
        parsed = urllib.parse.urlparse(url)
        return parsed.scheme in ("http", "https") and bool(parsed.netloc)
    except Exception:
        return False


class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, format: str, *args) -> None:
        sys.stdout.write(f"[{self.address_string()}] {format % args}\n")

    def send_json(self, code: int, payload: dict) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_json_body(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0 or length > 65536:
            return {}
        raw = self.rfile.read(length)
        return json.loads(raw.decode("utf-8"))

    def check_pin(self, supplied_pin: str) -> bool:
        if not PIN_CODE:
            return True
        return hmac.compare_digest(supplied_pin.strip(), PIN_CODE)

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == "/" or path == "/index.html":
            html_path = BASE_DIR / "index.html"
            data = html_path.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if path == "/api/config":
            self.send_json(200, {"pinRequired": bool(PIN_CODE)})
            return

        if path == "/api/info":
            qs = urllib.parse.parse_qs(parsed.query)
            url = (qs.get("url") or [""])[0].strip()
            if not is_valid_http_url(url):
                self.send_json(400, {"ok": False, "error": "Invalid URL"})
                return
            self.send_json(200, fetch_video_info(url))
            return

        if path.startswith("/api/status/"):
            job_id = path.removeprefix("/api/status/").strip("/")
            with JOBS_LOCK:
                job = JOBS.get(job_id)
                snapshot = dict(job) if job else None
            if not snapshot:
                self.send_json(404, {"error": "Job not found"})
                return
            self.send_json(
                200,
                {
                    "state": snapshot["state"],
                    "progress": snapshot["progress"],
                    "statusText": snapshot["status_text"],
                    "fileName": snapshot.get("file_name", ""),
                    "error": snapshot.get("error", ""),
                },
            )
            return

        if path.startswith("/api/file/"):
            job_id = path.removeprefix("/api/file/").strip("/")
            with JOBS_LOCK:
                job = JOBS.get(job_id)
                snapshot = dict(job) if job else None
            if not snapshot or snapshot.get("state") != "ready":
                self.send_json(404, {"error": "File not ready"})
                return

            file_path = Path(snapshot["file_path"])
            if not file_path.is_file():
                self.send_json(404, {"error": "File missing"})
                return

            mime, _ = mimetypes.guess_type(file_path.name)
            mime = mime or "application/octet-stream"
            size = file_path.stat().st_size
            ascii_name = file_path.name.encode("ascii", "ignore").decode("ascii") or "download"
            utf8_name = urllib.parse.quote(file_path.name)

            self.send_response(200)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(size))
            self.send_header(
                "Content-Disposition",
                f'attachment; filename="{ascii_name}"; filename*=UTF-8\'\'{utf8_name}',
            )
            self.end_headers()

            try:
                with open(file_path, "rb") as f:
                    while True:
                        chunk = f.read(65536)
                        if not chunk:
                            break
                        self.wfile.write(chunk)
            finally:
                temp_dir = snapshot.get("temp_dir")
                update_job(job_id, state="downloaded")
                if temp_dir:
                    shutil.rmtree(temp_dir, ignore_errors=True)
            return

        self.send_json(404, {"error": "Not found"})

    def do_POST(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path != "/api/start":
            self.send_json(404, {"error": "Not found"})
            return

        try:
            body = self.read_json_body()
        except Exception:
            self.send_json(400, {"error": "Invalid JSON"})
            return

        if not self.check_pin(str(body.get("pin", ""))):
            self.send_json(403, {"error": "Incorrect PIN"})
            return

        url = str(body.get("url", "")).strip()
        fmt = str(body.get("format", "1080")).strip()
        if not is_valid_http_url(url):
            self.send_json(400, {"error": "Please paste a valid http/https video URL."})
            return
        if fmt not in FORMAT_ARGS:
            self.send_json(400, {"error": "Unsupported format."})
            return

        job_id = uuid.uuid4().hex
        with JOBS_LOCK:
            JOBS[job_id] = {
                "state": "working",
                "progress": 2,
                "status_text": "Queued...",
                "created_at": time.time(),
            }

        t = threading.Thread(target=run_download_job, args=(job_id, url, fmt), daemon=True)
        t.start()
        self.send_json(200, {"jobId": job_id})


def get_lan_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"


def main() -> None:
    threading.Thread(target=cleanup_old_jobs, daemon=True).start()
    server = http.server.ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    lan_ip = get_lan_ip()
    print("=" * 52)
    print("  yt-grab is running!")
    print(f"  Local:   http://localhost:{PORT}")
    print(f"  LAN:     http://{lan_ip}:{PORT}")
    if PIN_CODE:
        print("  PIN:     enabled")
    print("  Press Ctrl+C to stop.")
    print("=" * 52)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping yt-grab...")
        server.shutdown()


if __name__ == "__main__":
    main()
